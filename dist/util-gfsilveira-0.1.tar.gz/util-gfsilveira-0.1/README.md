Diverse and useful functions for various actions.

Use, meu_uteis() to know the functions.

## License
MIT License